---
title : "Tạo kết nối đến máy chủ EC2"
date :  "`r Sys.Date()`" 
weight : 3 
chapter : false
pre : " <b> 3. </b> "
---

Trong bước này, chúng ta sẽ thực hiện tạo kết nối đến các máy chủ EC2 của chúng ta, nằm trong cả public và private subnet.

### Nội dung
3.1. [Tạo Kết nối đến máy chủ EC2 Public](3.1-public-instance/) \
3.2. [Tạo Kết nối đến máy chủ EC2 Private](3.2-private-instance/) 
